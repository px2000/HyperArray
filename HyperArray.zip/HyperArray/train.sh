#!/bin/bash

python train.py --device 0 \
                          --method  UM_SRNet \
                          --mask_dir  /mask/ \
                          --epoch_sam_num 2286 \
                          --train_data_path /data/Train/ \
                          --val_data_path /data/Val/ \
                          --model_dir  ./save_model/... \
                          --batch_size 4 \
                          --end_epoch 300 \
                        

